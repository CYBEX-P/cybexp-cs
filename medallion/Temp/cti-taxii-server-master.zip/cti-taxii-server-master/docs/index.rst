.. medallion documentation master file, created by
   sphinx-quickstart on Tue Nov 28 20:47:27 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to medallion's documentation!
=====================================

*Medallion* is a minimal implementation of a TAXII 2.0 Server in Python.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   compatibility
   custom_backend
   mongodb_schema



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
