MEDIA_TYPE_TAXII_ANY = "application/vnd.oasis.taxii+json"
MEDIA_TYPE_TAXII_V20 = "{media}; version=2.0".format(media=MEDIA_TYPE_TAXII_ANY)
MEDIA_TYPE_STIX_ANY = "application/vnd.oasis.stix+json"
MEDIA_TYPE_STIX_V20 = "{media}; version=2.0".format(media=MEDIA_TYPE_STIX_ANY)
